$.post('post.php', {
	type: '2',
	title:'very important',
	content:'Down with CipherIsland!!',
	form:'content'
	}
)

